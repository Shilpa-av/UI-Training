var userInfo= [
    {
      "_id": "5f570aca55adcd796f813023",
      "index": 0,
      "guid": "4e2c204a-89f4-4fef-a3c5-449dba34ab84",
      "isActive": false,
      "balance": "$3,619.33",
      "picture": "http://placehold.it/32x32",
      "age": 24,
      "eyeColor": "blue",
      "name": "Caitlin Nelson",
      "gender": "female",
      "company": "SPEEDBOLT",
      "email": "caitlinnelson@speedbolt.com",
      "phone": "+1 (945) 564-2456",
      "address": "477 Malbone Street, Kempton, California, 2194",
      "about": "Enim quis incididunt elit commodo sunt consectetur occaecat exercitation qui sit in sint. Mollit reprehenderit laborum consequat eiusmod nostrud nostrud. Cupidatat nisi dolor veniam veniam aliquip ad. Pariatur adipisicing tempor et consectetur deserunt nostrud ut occaecat anim dolor pariatur minim ex dolor. Fugiat mollit magna sit commodo anim. Pariatur Lorem qui ut anim adipisicing deserunt labore enim deserunt. Labore sint incididunt fugiat elit velit labore nostrud eiusmod ad culpa duis.\r\n",
      "registered": "2014-01-05T08:14:50 -06:-30",
      "latitude": -89.226962,
      "longitude": 0.755675,
      "tags": [
        "Lorem",
        "sunt",
        "consequat",
        "ipsum",
        "pariatur",
        "occaecat",
        "ea"
      ],
      "friends": [
        {
          "id": 0,
          "name": "Mason Johnston"
        },
        {
          "id": 1,
          "name": "Roman Mcgowan"
        },
        {
          "id": 2,
          "name": "Diaz Hoffman"
        }
      ],
      "greeting": "Hello, Caitlin Nelson! You have 7 unread messages.",
      "favoriteFruit": "apple"
    },
    {
      "_id": "5f570aca6d8a89d3a1a4617d",
      "index": 1,
      "guid": "1f031ba9-1abf-4e5f-b4a9-9db533511ca2",
      "isActive": false,
      "balance": "$1,834.81",
      "picture": "http://placehold.it/32x32",
      "age": 35,
      "eyeColor": "blue",
      "name": "Slater Mcpherson",
      "gender": "male",
      "company": "COMBOGEN",
      "email": "slatermcpherson@combogen.com",
      "phone": "+1 (877) 538-3672",
      "address": "845 Langham Street, Linganore, Mississippi, 1394",
      "about": "Nulla non irure Lorem Lorem. Commodo consequat est fugiat cupidatat minim mollit pariatur quis. Et do magna minim nisi laboris veniam est non eiusmod proident voluptate. Anim velit laborum est mollit quis dolore. Exercitation est aliquip ad eu deserunt esse eiusmod minim ullamco. Incididunt irure cillum culpa anim pariatur duis qui tempor ipsum ea enim.\r\n",
      "registered": "2015-09-27T12:08:53 -06:-30",
      "latitude": 29.657201,
      "longitude": 64.589192,
      "tags": [
        "sint",
        "reprehenderit",
        "excepteur",
        "commodo",
        "amet",
        "proident",
        "incididunt"
      ],
      "friends": [
        {
          "id": 0,
          "name": "Blanche Gray"
        },
        {
          "id": 1,
          "name": "Isabelle Owen"
        },
        {
          "id": 2,
          "name": "Mindy Long"
        }
      ],
      "greeting": "Hello, Slater Mcpherson! You have 6 unread messages.",
      "favoriteFruit": "apple"
    },
    {
      "_id": "5f570aca3ab99b82fa34ec9a",
      "index": 2,
      "guid": "15b24553-2a5a-45ad-a549-a851b8c78b8f",
      "isActive": true,
      "balance": "$1,438.28",
      "picture": "http://placehold.it/32x32",
      "age": 33,
      "eyeColor": "brown",
      "name": "Kirsten Hull",
      "gender": "female",
      "company": "CHILLIUM",
      "email": "kirstenhull@chillium.com",
      "phone": "+1 (940) 508-2770",
      "address": "828 Raleigh Place, Lafferty, Massachusetts, 6325",
      "about": "Dolor id minim quis minim ut voluptate labore aute magna sint quis. Dolor voluptate mollit irure minim est id ullamco elit officia labore anim voluptate qui qui. Tempor anim eu incididunt aute ullamco incididunt aliqua irure consequat ad eu sit et eiusmod. Sunt voluptate do Lorem aute ea dolore sint et exercitation do veniam ex. Lorem aute do ea laboris tempor irure aliqua veniam irure laboris Lorem fugiat in ipsum.\r\n",
      "registered": "2019-06-30T11:58:44 -06:-30",
      "latitude": -54.730102,
      "longitude": 35.873943,
      "tags": [
        "mollit",
        "dolor",
        "nostrud",
        "tempor",
        "aliqua",
        "culpa",
        "ullamco"
      ],
      "friends": [
        {
          "id": 0,
          "name": "Nixon Mendez"
        },
        {
          "id": 1,
          "name": "Walls Hooper"
        },
        {
          "id": 2,
          "name": "Bates George"
        }
      ],
      "greeting": "Hello, Kirsten Hull! You have 3 unread messages.",
      "favoriteFruit": "strawberry"
    },
    {
      "_id": "5f570aca708a5ab13bf79ca7",
      "index": 3,
      "guid": "ede576e6-2768-4bc0-bf3e-7f9ab62c048c",
      "isActive": true,
      "balance": "$1,946.66",
      "picture": "http://placehold.it/32x32",
      "age": 32,
      "eyeColor": "blue",
      "name": "Cleveland Moses",
      "gender": "male",
      "company": "AUTOGRATE",
      "email": "clevelandmoses@autograte.com",
      "phone": "+1 (973) 522-3188",
      "address": "511 Fillmore Avenue, Yogaville, South Carolina, 752",
      "about": "Dolor sunt in in pariatur Lorem in deserunt in. Et incididunt officia dolore dolor sunt minim deserunt incididunt ex nulla et in aliquip quis. Aliqua dolore aute elit sit enim consequat eu qui.\r\n",
      "registered": "2020-08-06T10:43:04 -06:-30",
      "latitude": 17.557025,
      "longitude": 118.241502,
      "tags": [
        "esse",
        "adipisicing",
        "aliquip",
        "sit",
        "exercitation",
        "anim",
        "adipisicing"
      ],
      "friends": [
        {
          "id": 0,
          "name": "Swanson Adkins"
        },
        {
          "id": 1,
          "name": "Bonita Armstrong"
        },
        {
          "id": 2,
          "name": "Hooper Santos"
        }
      ],
      "greeting": "Hello, Cleveland Moses! You have 6 unread messages.",
      "favoriteFruit": "strawberry"
    },
    {
      "_id": "5f570aca1c3f0d743795a86e",
      "index": 4,
      "guid": "c76f0e08-4f9c-4e79-8ba2-fed8fb349ef8",
      "isActive": true,
      "balance": "$3,120.15",
      "picture": "http://placehold.it/32x32",
      "age": 29,
      "eyeColor": "green",
      "name": "Pace Raymond",
      "gender": "male",
      "company": "COMBOT",
      "email": "paceraymond@combot.com",
      "phone": "+1 (904) 591-3132",
      "address": "956 Canarsie Road, Wyano, Connecticut, 2923",
      "about": "Excepteur est reprehenderit deserunt officia in proident do ut ex esse id. Enim elit ad amet minim ea. Elit incididunt commodo qui consectetur. Non laboris quis in sunt laboris magna elit aute adipisicing anim cupidatat in.\r\n",
      "registered": "2019-10-23T04:30:57 -06:-30",
      "latitude": 67.22634,
      "longitude": 54.568776,
      "tags": [
        "id",
        "amet",
        "ea",
        "aliquip",
        "reprehenderit",
        "sunt",
        "pariatur"
      ],
      "friends": [
        {
          "id": 0,
          "name": "Alice Donaldson"
        },
        {
          "id": 1,
          "name": "Allison Russo"
        },
        {
          "id": 2,
          "name": "Angelique Poole"
        }
      ],
      "greeting": "Hello, Pace Raymond! You have 6 unread messages.",
      "favoriteFruit": "strawberry"
    },
    {
      "_id": "5f570acaf5eb4b8d0803c21c",
      "index": 5,
      "guid": "a2ffdc59-a2ac-48d5-a065-47b6ce9e8c53",
      "isActive": false,
      "balance": "$2,598.17",
      "picture": "http://placehold.it/32x32",
      "age": 32,
      "eyeColor": "green",
      "name": "Morse Tillman",
      "gender": "male",
      "company": "NEWCUBE",
      "email": "morsetillman@newcube.com",
      "phone": "+1 (974) 534-2260",
      "address": "568 Livingston Street, Cataract, Illinois, 9090",
      "about": "Incididunt qui ipsum mollit officia. Nisi ad consequat id anim ex fugiat commodo commodo Lorem magna magna cillum. Est anim tempor aute exercitation esse reprehenderit deserunt ut sit. Consequat laboris duis occaecat ex nulla excepteur. Occaecat voluptate commodo voluptate duis et minim. Id in dolore ut ex do.\r\n",
      "registered": "2019-12-31T08:08:27 -06:-30",
      "latitude": -65.328743,
      "longitude": 58.569207,
      "tags": [
        "nostrud",
        "aute",
        "occaecat",
        "labore",
        "tempor",
        "incididunt",
        "culpa"
      ],
      "friends": [
        {
          "id": 0,
          "name": "Glass Gillespie"
        },
        {
          "id": 1,
          "name": "Webb Garrison"
        },
        {
          "id": 2,
          "name": "Chang Richard"
        }
      ],
      "greeting": "Hello, Morse Tillman! You have 9 unread messages.",
      "favoriteFruit": "apple"
    },
    {
      "_id": "5f570aca97841e041d22ec95",
      "index": 6,
      "guid": "edd299b1-2c71-42a8-91a2-cac434a634d0",
      "isActive": false,
      "balance": "$2,670.40",
      "picture": "http://placehold.it/32x32",
      "age": 22,
      "eyeColor": "blue",
      "name": "Alyce Merritt",
      "gender": "female",
      "company": "TYPHONICA",
      "email": "alycemerritt@typhonica.com",
      "phone": "+1 (863) 573-2921",
      "address": "102 Conduit Boulevard, Graniteville, New Jersey, 1078",
      "about": "Sunt duis non qui deserunt aute magna aute labore. Exercitation eiusmod aliqua officia quis. Eu dolore deserunt est ullamco sint nostrud commodo tempor dolore laboris elit. Qui fugiat adipisicing laboris sit velit nisi minim. Qui velit commodo magna amet incididunt pariatur laborum reprehenderit. Aliqua esse sunt commodo velit reprehenderit. Incididunt quis laborum dolore veniam commodo.\r\n",
      "registered": "2017-05-06T07:51:11 -06:-30",
      "latitude": 7.105046,
      "longitude": -42.626893,
      "tags": [
        "sit",
        "labore",
        "ullamco",
        "amet",
        "Lorem",
        "est",
        "laboris"
      ],
      "friends": [
        {
          "id": 0,
          "name": "Saunders Cox"
        },
        {
          "id": 1,
          "name": "Parks Farrell"
        },
        {
          "id": 2,
          "name": "Davenport Pruitt"
        }
      ],
      "greeting": "Hello, Alyce Merritt! You have 6 unread messages.",
      "favoriteFruit": "banana"
    }
  ]


var filteredUser = userInfo.filter(function(item, index){
    return item.favoriteFruit=="apple";
}).map(function(item,index){
    return (item.name);
});

console.log(filteredUser);

