for(var i=10;i<15;i++)
{
    console.log(i);
}