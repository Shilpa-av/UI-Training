var file = require('fs');
file.writeFileSync("./demo.txt","Shilpa");